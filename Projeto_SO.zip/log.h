/*
    Realizado por:
        João Bernardo de Jesus Santos, nº2020218995
        Gonçalo Fernandes Diogo de Almeida, nº2020218868
*/

#ifndef LOG_H
#define LOG_H

#define MSG_LEN 256

int create_log();
void close_log();
void log_write(char *s);

#endif
