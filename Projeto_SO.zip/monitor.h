/*
    Realizado por:
        João Bernardo de Jesus Santos, nº2020218995
        Gonçalo Fernandes Diogo de Almeida, nº2020218868
*/

#ifndef MONITOR_H
#define MONITOR_H

//#define DEBUG_MON //uncomment this line to print monitor debug messages

void monitor();

#endif
